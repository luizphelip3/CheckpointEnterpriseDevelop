package br.com.fiap.entity;

import javax.persistence.*;
import java.util.Calendar;

@Entity
@Table(name="TB_ATENDIMENTO")
@SequenceGenerator(name="atendimento", sequenceName="SQ_TB_ATENDIMENTO", allocationSize=1)

public class Atendimento {
	@Id
	@Column(name="cd_id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator ="funcionario")
	private Integer codigo;
	
	@Temporal(TemporalType.DATE)
	@Column(name="dt_data")
	private Calendar data;
	
	@Column(name="tp_duracao")
	private Integer duracao;
	
	@Column(name="as_assunto")
	private String assunto;

	public Atendimento(Integer codigo, Calendar data, Integer duracao, String assunto) {
		super();
		this.codigo = codigo;
		this.data = data;
		this.duracao = duracao;
		this.assunto = assunto;
	}

	public Atendimento(Calendar data, Integer duracao, String assunto) {
		super();
		this.data = data;
		this.duracao = duracao;
		this.assunto = assunto;
	}

	public Atendimento() {
		super();
	}

	public Integer getCodigo() {
		return codigo;
	}

	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	public Calendar getData() {
		return data;
	}

	public void setData(Calendar data) {
		this.data = data;
	}

	public Integer getDuracao() {
		return duracao;
	}

	public void setDuracao(Integer duracao) {
		this.duracao = duracao;
	}

	public String getAssunto() {
		return assunto;
	}

	public void setAssunto(String assunto) {
		this.assunto = assunto;
	}

	@Override
	public String toString() {
		return "Atendimento [codigo=" + codigo + ", data=" + data + ", duracao=" + duracao + ", assunto=" + assunto
				+ "]";
	}
	

	
}
