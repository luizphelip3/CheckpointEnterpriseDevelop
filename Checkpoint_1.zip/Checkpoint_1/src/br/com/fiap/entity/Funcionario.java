package br.com.fiap.entity;

import javax.persistence.*;
import java.util.Calendar;

@Entity
@Table(name="TB_FUNCIONARIO")
@SequenceGenerator(name="funcionario", sequenceName="SQ_TB_FUNCIONARIO", allocationSize=1)

public class Funcionario {
	@Id
	@Column(name="cd_id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="funcionario")
	private Integer codigo;
	
	@Column(name="nm_nome")
	private String nome;
	
	@Column(name="em_email")
	private String email;
	
	@Column(name="cd_senha")
	private String senha;
	
	@Temporal(TemporalType.DATE)
	@Column(name="dt_cadastro")
	private Calendar cadastro;
	
	@Column(name="nr_telefone")
	private String telefone;

	public Funcionario(Integer codigo, String nome, String email, String senha, Calendar cadastro, String telefone) {
		super();
		this.codigo = codigo;
		this.nome = nome;
		this.email = email;
		this.senha = senha;
		this.cadastro = cadastro;
		this.telefone = telefone;
	}

	public Funcionario(String nome, String email, String senha, Calendar cadastro, String telefone) {
		super();
		this.nome = nome;
		this.email = email;
		this.senha = senha;
		this.cadastro = cadastro;
		this.telefone = telefone;
	}

	public Funcionario() {
		super();
	}

	public Integer getCodigo() {
		return codigo;
	}

	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public Calendar getCadastro() {
		return cadastro;
	}

	public void setCadastro(Calendar cadastro) {
		this.cadastro = cadastro;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	@Override
	public String toString() {
		return "Funcionario [codigo=" + codigo + ", nome=" + nome + ", email=" + email + ", senha=" + senha
				+ ", cadastro=" + cadastro.getTime() + ", telefone=" + telefone + "]";
	}
	
	

	

}
	
