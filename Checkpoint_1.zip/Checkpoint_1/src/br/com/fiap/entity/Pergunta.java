package br.com.fiap.entity;

import javax.persistence.*;

@Entity
@Table(name="TB_PERGUNTA")
@SequenceGenerator(name="pergunta", sequenceName="SQ_TB_PERGUNTA", allocationSize=1)

public class Pergunta {
	@Id
	@Column(name="cd_id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="pergunta")
	private Integer codigo;
	
	@Column(name="tx_texto")
	private String texto;
	
	@Column(name="tp_duracao")
	private Integer duracao;

	public Pergunta(Integer codigo, String texto, Integer duracao) {
		super();
		this.codigo = codigo;
		this.texto = texto;
		this.duracao = duracao;
	}

	public Pergunta(String texto, Integer duracao) {
		super();
		this.texto = texto;
		this.duracao = duracao;
	}

	public Pergunta() {
		super();
	}

	public Integer getCodigo() {
		return codigo;
	}

	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	public String getTexto() {
		return texto;
	}

	public void setTexto(String texto) {
		this.texto = texto;
	}

	public Integer getDuracao() {
		return duracao;
	}

	public void setDuracao(Integer duracao) {
		this.duracao = duracao;
	}

	@Override
	public String toString() {
		return "Pergunta [codigo=" + codigo + ", texto=" + texto + ", duracao=" + duracao + "]";
	}
	
	
	
}
