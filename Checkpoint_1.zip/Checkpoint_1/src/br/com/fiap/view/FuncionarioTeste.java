package br.com.fiap.view;

import java.util.Calendar;

import javax.persistence.EntityManager;
import javax.persistence.EntityNotFoundException;
import br.com.fiap.dao.FuncionarioDao;
import br.com.fiap.dao.impl.FuncionarioDaoImpl;
import br.com.fiap.entity.Funcionario;
import br.com.fiap.exception.CommitException;
import br.com.fiap.singleton.EntityManagerFactorySingleton;

public class FuncionarioTeste {
	public static void main(String[] args) {
		EntityManager em = EntityManagerFactorySingleton.getInstance().createEntityManager();
		FuncionarioDao dao = new FuncionarioDaoImpl(em);
        // public Atendimento(Calendar data, Integer duracao, Integer assunto)
        Funcionario funcionario = new Funcionario("Luiz Phelipe", "luiz_phelip3@hotmail.com", "senhaforte", Calendar.getInstance(), "77998363648");
        try{
            dao.insert(funcionario);
            dao.commit();
            System.out.println("Funcionario inserido com sucesso");
        }catch(CommitException e){
            System.out.println(e.getMessage());
        }

        try{
            funcionario = dao.findById(1);
            System.out.println(funcionario);
        }catch(EntityNotFoundException e){
            System.out.println(e.getMessage());
        }

        em.close();
        EntityManagerFactorySingleton.getInstance().close();
		
	}

}
