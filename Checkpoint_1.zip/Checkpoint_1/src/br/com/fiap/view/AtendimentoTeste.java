package br.com.fiap.view;

import java.util.Calendar;

import javax.persistence.EntityManager;
import javax.persistence.EntityNotFoundException;

import br.com.fiap.dao.AtendimentoDao;
import br.com.fiap.dao.impl.AtendimentoDaoImpl;
import br.com.fiap.entity.Atendimento;
import br.com.fiap.exception.CommitException;
import br.com.fiap.singleton.EntityManagerFactorySingleton;

public class AtendimentoTeste {
	public static void main(String[] args) {
		EntityManager em = EntityManagerFactorySingleton.getInstance().createEntityManager();

        AtendimentoDao dao = new AtendimentoDaoImpl(em);
        // public Atendimento(Calendar data, Integer duracao, Integer assunto)
        Atendimento atendimento = new Atendimento(Calendar.getInstance(), 20, "Financeiro");
        try{
            dao.insert(atendimento);
            dao.commit();
            System.out.println("Atendimento inserido com sucesso");
        }catch(CommitException e){
            System.out.println(e.getMessage());
        }

        try{
            atendimento = dao.findById(1);
            System.out.println(atendimento);
        }catch(EntityNotFoundException e){
            System.out.println(e.getMessage());
        }

        em.close();
        EntityManagerFactorySingleton.getInstance().close();
    }
}
