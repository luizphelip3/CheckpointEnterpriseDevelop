package br.com.fiap.view;

import javax.persistence.EntityManager;
import javax.persistence.EntityNotFoundException;

import br.com.fiap.dao.RespostaDao;
import br.com.fiap.dao.impl.RespostaDaoImpl;
import br.com.fiap.entity.Resposta;
import br.com.fiap.exception.CommitException;
import br.com.fiap.singleton.EntityManagerFactorySingleton;

public class RespostaTeste {
	public static void main(String[] args) {
		EntityManager em = EntityManagerFactorySingleton.getInstance().createEntityManager();
		RespostaDao dao = new RespostaDaoImpl(em);
        // public Atendimento(Calendar data, Integer duracao, Integer assunto)
        Resposta resposta = new Resposta("Sim, consigo!",120);
        try{
            dao.insert(resposta);
            dao.commit();
            System.out.println("Resposta feita com sucesso");
        }catch(CommitException e){
            System.out.println(e.getMessage());
        }

        try{
            resposta = dao.findById(1);
            System.out.println(resposta);
        }catch(EntityNotFoundException e){
            System.out.println(e.getMessage());
        }

        em.close();
        EntityManagerFactorySingleton.getInstance().close();
		
	}
	
}
