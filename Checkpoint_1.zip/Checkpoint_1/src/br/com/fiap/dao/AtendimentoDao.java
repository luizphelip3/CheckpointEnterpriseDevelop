package br.com.fiap.dao;

import br.com.fiap.entity.Atendimento;


public interface AtendimentoDao extends GenericDao<Atendimento, Integer> {

}
