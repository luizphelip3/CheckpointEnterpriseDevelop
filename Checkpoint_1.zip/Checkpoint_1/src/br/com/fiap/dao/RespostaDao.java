package br.com.fiap.dao;

import br.com.fiap.entity.Resposta;

public interface RespostaDao extends GenericDao<Resposta,Integer>{

}
