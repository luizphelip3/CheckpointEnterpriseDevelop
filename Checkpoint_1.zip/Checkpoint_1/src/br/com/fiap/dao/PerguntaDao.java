package br.com.fiap.dao;

import br.com.fiap.entity.Pergunta;

public interface PerguntaDao extends GenericDao<Pergunta, Integer> {

}
