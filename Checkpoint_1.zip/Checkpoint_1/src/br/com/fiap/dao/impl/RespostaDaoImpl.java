package br.com.fiap.dao.impl;

import javax.persistence.EntityManager;

import br.com.fiap.dao.RespostaDao;
import br.com.fiap.entity.Resposta;


public class RespostaDaoImpl extends GenericDaoImpl<Resposta, Integer> implements RespostaDao {
	public RespostaDaoImpl(EntityManager em){
		super(em);
	}
	

}
