package br.com.fiap.dao.impl;

import javax.persistence.EntityManager;

import br.com.fiap.dao.AtendimentoDao;
import br.com.fiap.entity.Atendimento;


public class AtendimentoDaoImpl extends GenericDaoImpl<Atendimento, Integer> implements AtendimentoDao {
	public AtendimentoDaoImpl(EntityManager em){
		super(em);
	}
	

}
