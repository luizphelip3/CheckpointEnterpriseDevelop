package br.com.fiap.dao.impl;

import javax.persistence.EntityManager;

import br.com.fiap.dao.PerguntaDao;
import br.com.fiap.entity.Pergunta;


public class PerguntaDaoImpl extends GenericDaoImpl<Pergunta, Integer> implements PerguntaDao {
	public PerguntaDaoImpl(EntityManager em){
		super(em);
	}
	

}
