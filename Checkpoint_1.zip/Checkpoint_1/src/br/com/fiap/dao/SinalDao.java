package br.com.fiap.dao;

import br.com.fiap.entity.Sinal;

public interface SinalDao extends GenericDao<Sinal,Integer>{

}
